package com.tekcreek.socketprg.dbsocket.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tekcreek.socketprg.dbsocket.datasource.DBSocketDataSource;
import com.tekcreek.socketprg.dbsocket.model.Emp;

public class EmpRepository {
	
	DBSocketDataSource dbSockDS = new DBSocketDataSource();
	
	public List<Emp> findByNamePattern(String name) throws Exception {
		Connection con = dbSockDS.getConnection();
		try {
			PreparedStatement ps = 
					con.prepareStatement("select * from emp where name like ?");
			ps.setString(1, "%" + name + "%");
			ResultSet rs = ps.executeQuery();
			List<Emp> empList = new ArrayList<Emp>();
			while (rs.next()) {
				Emp obj = new Emp(rs.getInt(1), rs.getString(2), rs.getDouble(3));
				empList.add(obj);
			}
			return empList;
		} finally {
			con.close();
		}
	}
}
