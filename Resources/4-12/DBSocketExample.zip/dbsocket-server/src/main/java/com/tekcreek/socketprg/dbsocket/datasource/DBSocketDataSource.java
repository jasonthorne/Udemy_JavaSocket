package com.tekcreek.socketprg.dbsocket.datasource;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBSocketDataSource {
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() throws Exception {
		Connection con = 
				DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/dbsockex", "dbsockex", "dbsockex");
		return con;
	}
}
