package com.tekcreek.socketprg.dbsocket.server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.tekcreek.socketprg.dbsocket.core.WorkerTask;

public class App {
	public static void main(String[] args) throws Exception {
		
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		ServerSocket serSock = new ServerSocket(9090);
		while (true) {
			try {
				Socket sock = serSock.accept();
				executorService.execute(new WorkerTask(sock));
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
}
