create schema `dbsockex`;

create user `dbsockex` identified by 'dbsockex';

use 	`dbsockex`;
grant all privileges on `dbsockex`.* to `dbsockex`@'%';


create table `emp` (
	`empno` integer PRIMARY KEY,
    `name` varchar(20),
    `salary` numeric(10,2)
);

insert into `emp` values(1, 'a', 1000);
insert into `emp` values(2, 'ab', 2000);
insert into `emp` values(3, 'c', 3000);


select * from `emp`;