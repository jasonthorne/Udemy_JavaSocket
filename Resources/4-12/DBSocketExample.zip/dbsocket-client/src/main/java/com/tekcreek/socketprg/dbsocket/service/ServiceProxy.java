package com.tekcreek.socketprg.dbsocket.service;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.List;

import com.google.gson.Gson;
import com.tekcreek.socketprg.dbsocket.model.Emp;
import com.tekcreek.socketprg.dbsocket.model.Request;
import com.tekcreek.socketprg.dbsocket.model.Response;

public class ServiceProxy {
	
	Socket sock;
	Gson gson = new Gson();
	DataInputStream din = null;
	DataOutputStream dout = null;
	
	public ServiceProxy(Socket sock) {
		this.sock = sock;
		try {
			this.din = new DataInputStream(sock.getInputStream());
			this.dout = new DataOutputStream(sock.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public List<Emp> fetchResults(String name) {
		Request request = new Request(name);
		String inputJSON = gson.toJson(request);
		try {
			dout.writeUTF(inputJSON);
			String outputJSON = din.readUTF();
			Response response = gson.fromJson(outputJSON, Response.class);
			return response.getResult();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void close() {
		if (sock != null) {
			try {
				sock.close();
			} catch(Exception e) {}
		}
	}
}
