package com.tekcreek.socketprg.dbsocket.model;

public class Request {
	String name;

	public Request(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
