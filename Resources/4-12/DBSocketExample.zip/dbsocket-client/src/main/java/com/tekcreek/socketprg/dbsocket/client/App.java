package com.tekcreek.socketprg.dbsocket.client;

import java.net.Socket;

import com.tekcreek.socketprg.dbsocket.client.view.ClientWindow;
import com.tekcreek.socketprg.dbsocket.service.ServiceProxy;

public class App {
    public static void main( String[] args ) throws Exception {
    	Socket sock = new Socket("localhost", 9090);
    	ServiceProxy proxy = new ServiceProxy(sock);
    	ClientWindow window = new ClientWindow(proxy);
    	window.setVisible(true);
    }
}
