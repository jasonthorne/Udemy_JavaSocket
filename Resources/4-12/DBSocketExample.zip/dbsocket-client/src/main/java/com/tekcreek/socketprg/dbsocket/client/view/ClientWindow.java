package com.tekcreek.socketprg.dbsocket.client.view;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tekcreek.socketprg.dbsocket.model.Emp;
import com.tekcreek.socketprg.dbsocket.service.ServiceProxy;

public class ClientWindow extends JFrame {

	private static final long serialVersionUID = 1L;
	
	JTextField txtSearch = new JTextField();
	JButton btnSearch = new JButton("search");
	JTextArea txtResults = new JTextArea();
	
	ServiceProxy proxy = null;
	Gson gson = null;
	
	public ClientWindow(ServiceProxy serviceProxy) {
		
		this.proxy = serviceProxy;
		this.gson = new GsonBuilder().setPrettyPrinting().create();
		
		Box north = Box.createHorizontalBox();
		north.add( txtSearch );
		north.add( btnSearch );
		
		Box center = Box.createVerticalBox();
		Border titleResults = BorderFactory.createTitledBorder("Results");
		center.setBorder(titleResults);
		JScrollPane scrollPane = new JScrollPane( txtResults );
		center.add( scrollPane );
		
		Container mainContainer = getContentPane();
		mainContainer.add( north , "North" );
		mainContainer.add( center , "Center" );

		btnSearch.addActionListener( new SearchHandler() );	

		setBounds( 100 , 100 , 600 , 600 );
		setResizable( false );
		
		// setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				proxy.close();
				System.exit(0);
			}
		});
	}

	class SearchHandler implements ActionListener {
		public void actionPerformed( ActionEvent e ) {
			String textPattern = txtSearch.getText();
			try{
				List<Emp> empList = proxy.fetchResults(textPattern);
				String resultJson = gson.toJson(empList);
				txtResults.setText(resultJson);
			}catch (Exception exp){System.out.println( exp ); }
		}
	 }

}
